<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<title>MoLoyal - Customer Loyalty and Benefits Solution</title>
<meta charset="utf-8" />
<meta http-equiv="x-ua-compatible" content="ie=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href='http://fonts.googleapis.com/css?family=Ubuntu:400,400italic,700,700italic,300,300italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Euphoria+Script' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="./css/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 
<link rel="stylesheet" media="screen" href="./assets-newsletters/css/quick_newsletter.css"> 
<link rel="stylesheet" type="text/css" href="./css/tango/skin.css" />
<link rel="stylesheet" href="./css/layerslider/layerslider.css" />
<link rel="stylesheet" href="./css/colorbox.css" />
<link rel="stylesheet" href="./css/bootstrap.css" />
<link rel="stylesheet" href="./css/responsive.css" />
<link rel="stylesheet" href="./css/color-01.css" id="site-color" />
<link rel="stylesheet" href="./css/style.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>

</head>


<body>
    <div class="container">
	<div class="row">
		<div class="span12">
        	<!-- site logo	//-->
        	<a href=""><div class="site-logo"></div></a>
            <div class="header-sub-wrapper">
	<a href="https://moloyal.com/new/registration" class="button " style="background-color:blue">Register</a>
 
<a href="https://moloyal.com/customer/login" class="button button-color">Login</a>  
	<!-- header social buttons //-->
				<div class="header-social-buttons">
				    <a href=""><i class="icon-facebook"></i></a>
                    <a href=""><i class="icon-twitter"></i></a>
                    

                </div>
                <!-- header contacts //-->
                <div class="header-contacts hidden-phone visible-tablet visible-desktop header-contacts-2">
                    <p><span class="contact-1">Phone: </span><i class="icon-phone hidden-desktop visible-tablet"></i><strong>+234 -1-2953541</strong></p>
                    <p><span class="contact-2">Email: </span><i class="icon-envelope hidden-desktop visible-tablet"></i><a href="care@moloyal" target="_blank">care@moloyal.com</a></p>
                </div>
            </div>
            <!-- site desktop menu start //-->
            <nav class="site-desktop-menu site-desktop-menu-2">
            	<ul>
                	
                	<li>
                    	<a href="#home">home</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#about-moloyal">about MoLoyal</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#downloads">downloads</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#our-partners">our partners</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#contact-us">contact us</a>
                                	
                       
                    </li>
                    
                </ul>
      </nav>
            <!-- site desktop menu end //-->
            <!-- site desktop menu start //-->
            <nav class="site-mobile-menu site-mobile-menu-2">
            	<i class="icon-reorder"></i>
            	<ul>
                		<li>
                    	<a href="#home">home</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#about-moloyal">about MoLoyal</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#downloads">downloads</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#our-partners">our partners</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#contact-us">contact us</a>
                                	
                       
                    </li>
                </ul>
</nav>
            <!-- site desktop menu end //-->
        </div>
    </div>
</div>

  <div class="container">
  <h2 style= "text-align: center;">Buy Airtime</h2>
  <p>Please confirm your airtime order</p>
  <br>
  <form>
    <div class="form-group">
      <label for="phoneno" >Phone Number:</label>
      <input type="text" name="phoneno" id="phoneno" value="<?php echo $_GET['phoneno']; ?>">
      
    </div>
    
        <div class="form-group">
      <label for="mobilenetwork">Mobile Network:</label>
      <input type="text" name="network" id="network" value="<?php echo $_GET['mobilenetwork']; ?>">
    </div>
    <div class="form-group">
      <label for="amount">Amount:</label>
      <input type="text" name="amount" id="amount" value="<?php echo $_GET['amount']; ?>">
    </div>
    <div class="form-group">
      <label for="email">Email Address:</label>
      <input type="text" name="email" id="email" value="<?php echo $_GET['email']; ?>">
    </div>
    <div class="margiv-top-10">
        
	<button type="button" class="btn btn-primary" onClick="payWithRave()">Pay</button>
	<br>
	<br>
	<br>
	</div>
  </form>
</div>
 <script type="text/javascript" src="https://ravesandboxapi.flutterwave.com/flwv3-pug/getpaidx/api/flwpbf-inline.js"></script>
     <script>
//change to Live
    const API_publicKey = "FLWPUBK-d14fc4cdb94fea77773e5ef7922eb3a1-X";
var mobiles=document.getElementById("phoneno").value;
var amtse=document.getElementById("amount").value;
var netw=document.getElementById("network").value;
var email=document.getElementById("email").value;
    function payWithRave() {
        //alert(mobiles);
        
        var x = getpaidSetup({
            PBFPubKey: API_publicKey,
            customer_email: email,
            amount: amtse,
            customer_phone: mobiles,
            currency: "NGN",
            payment_method: "both",
            txref: 'ra-125433',
            meta: [{
                metaname: "mobilenetwork",
                metavalue: "AP1234"
            }],
            onclose: function() {},
            callback: function(response) {
                var txref = response.tx.txRef; // collect flwRef returned and pass to a           server page to complete status check.
                console.log("This is the response returned after a charge", response);
                if (
                    response.tx.chargeResponseCode == "00" ||
                    response.tx.chargeResponseCode == "0"
                ) {
                 window.location = "https://moloyal.com/paymentverify.php?txref="+txref; //Add your success page here
          } else {
            window.location = "https://moloyal.com/paymentverify.php?txref="+txref;  //Add your failure page here
          }

                x.close(); // use this to close the modal immediately after payment.
            }
        });
    }
    </script>
<!-- bottom line start //-->
<div class="bottom-line">
	<div class="container">
    	<div class="row">
        	<div class="span6">
            	<p>© 2017 All rights reserved.  MoLoyal by <a href="http://avante-cs.com" target="_blank">Avante Consulting Solutions</a></p>
            </div>
        	<div class="span6">
            	<p class="bottom-menu"><a href="consumer-benefits">Consumer Benefits</a> | <a href="business-benefits">Business Benefits</a> | <a href="faq">FAQ</a></p>
            </div>
        </div>
    </div>
</div>
<!-- bottom line end //-->

<!-- to the top start //-->
<div id="to-the-top"><i class="icon-angle-up"></i></div>
<!-- to the top end //-->



</body>

<!-- scripts start //-->
<script src="./js/jquery.js"></script>
<script src="./js/layerslider.kreaturamedia.jquery.js"></script>
<script src="./js/layerslider.transitions.js"></script>
<script src="./js/jquery-easing-1.3.js" type="text/javascript"></script>
<script src="./js/jquery-transit-modified.js" type="text/javascript"></script>
<script src="./js/jquery.jcarousel.min.js"></script>
<script type="text/javascript" src="./assets-newsletters/scripts/quick_newsletter.js"></script> 
<script src="./js/jquery.colorbox.js"></script>
<script src="./js/custom.js"></script>
<script>
jQuery(document).ready(function() {
});
</script>
<!-- scripts end //-->

</html>