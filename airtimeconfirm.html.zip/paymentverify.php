<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<title>MoLoyal - Customer Loyalty and Benefits Solution</title>
<meta charset="utf-8" />
<meta http-equiv="x-ua-compatible" content="ie=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href='http://fonts.googleapis.com/css?family=Ubuntu:400,400italic,700,700italic,300,300italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Euphoria+Script' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="./css/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 
<link rel="stylesheet" media="screen" href="./assets-newsletters/css/quick_newsletter.css"> 
<link rel="stylesheet" type="text/css" href="./css/tango/skin.css" />
<link rel="stylesheet" href="./css/layerslider/layerslider.css" />
<link rel="stylesheet" href="./css/colorbox.css" />
<link rel="stylesheet" href="./css/bootstrap.css" />
<link rel="stylesheet" href="./css/responsive.css" />
<link rel="stylesheet" href="./css/color-01.css" id="site-color" />
<link rel="stylesheet" href="./css/style.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>

</head>


<body>
    <div class="container">
	<div class="row">
		<div class="span12">
        	<!-- site logo	//-->
        	<a href=""><div class="site-logo"></div></a>
            <div class="header-sub-wrapper">
	<a href="https://moloyal.com/new/registration" class="button " style="background-color:blue">Register</a>
 
<a href="https://moloyal.com/customer/login" class="button button-color">Login</a>  
	<!-- header social buttons //-->
				<div class="header-social-buttons">
				    <a href=""><i class="icon-facebook"></i></a>
                    <a href=""><i class="icon-twitter"></i></a>
                    

                </div>
                <!-- header contacts //-->
                <div class="header-contacts hidden-phone visible-tablet visible-desktop header-contacts-2">
                    <p><span class="contact-1">Phone: </span><i class="icon-phone hidden-desktop visible-tablet"></i><strong>+234 -1-2953541</strong></p>
                    <p><span class="contact-2">Email: </span><i class="icon-envelope hidden-desktop visible-tablet"></i><a href="care@moloyal" target="_blank">care@moloyal.com</a></p>
                </div>
            </div>
            <!-- site desktop menu start //-->
            <nav class="site-desktop-menu site-desktop-menu-2">
            	<ul>
                	
                	<li>
                    	<a href="#home">home</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#about-moloyal">about MoLoyal</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#downloads">downloads</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#our-partners">our partners</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#contact-us">contact us</a>
                                	
                       
                    </li>
                    
                </ul>
      </nav>
            <!-- site desktop menu end //-->
            <!-- site desktop menu start //-->
            <nav class="site-mobile-menu site-mobile-menu-2">
            	<i class="icon-reorder"></i>
            	<ul>
                		<li>
                    	<a href="#home">home</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#about-moloyal">about MoLoyal</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#downloads">downloads</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#our-partners">our partners</a>
                                	
                       
                    </li>
					<li>
                    	<a href="#contact-us">contact us</a>
                                	
                       
                    </li>
                </ul>
</nav>
            <!-- site desktop menu end //-->
        </div>
    </div>
</div>


<br><br><br><br><br><br><br><br><br><br>


<?php
ini_set(display_error, 1);
    if (isset($_GET['txref'])) {
        echo $ref = $_GET['txref'];
        
        include("connect.php");
//$submit_order = mysqli_query($connect,"SELECT * FROM `paytransaction` WHERE order_no=$ref");
//$rows=mysqli_fetch_array($submit_order);
  //$amount=$rows[amount];



        //$amount = ""; //Correct Amount from Server
        $currency = ""; //Correct Currency from Server

        $query = array(
            //change to Live
            "SECKEY" => "FLWSECK-22095fcce8912f8f7a1a49b43388d50e-X",
            "txref" => $ref
        );

        $data_string = json_encode($query);
          
          //live url      
        //$ch = curl_init('https://api.ravepay.co/flwv3-pug/getpaidx/api/v2/verify ');   

         $ch = curl_init('https://ravesandboxapi.flutterwave.com/flwv3-pug/getpaidx/api/v2/verify');                                                                   
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                              
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

         $response = curl_exec($ch);

        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $header = substr($response, 0, $header_size);
        $body = substr($response, $header_size);

        curl_close($ch);

        $resp = json_decode($response, true);

      	 $paymentStatus = $resp['data']['status'];
      	 echo $mobilenetwork = ucfirst(strtolower($resp['data']['custnetworkprovider']));  
      	echo $mobilenetwork2 = ucfirst(strtolower($resp['data']['meta']['metavalue']));  
      	
         $chargeResponsecode = $resp['data']['chargecode'];
        $amount = $resp['data']['amount'];
        $chargeCurrency = $resp['data']['currency'];
         $phone = $resp['data']['custphone'];



	  	  if($mobilenetwork=='Mtn'){
	  $billid=1;
	  $itemcode='M05';
	  }elseif($mobilenetwork=='Glo' || $mobilenetwork=='Globacom' ){
	  $billid=19;
	  $itemcode='G05';
	  }elseif($mobilenetwork=='9mobile' || $mobilenetwork=='Etisalat'  ){
	  $billid=18;
	  $itemcode='E05';
	  }elseif($mobilenetwork=='Airtel'){
	  $billid=20;
	  $itemcode='A05';
	  }
        //if (($chargeResponsecode == "00" || $chargeResponsecode == "0") && ($chargeAmount == $amount)  && ($chargeCurrency == $currency)) {
            
             //if (($chargeResponsecode == "00" || $chargeResponsecode == "0") && ($chargeAmount == $amount) ) {
                 
                 if (($chargeResponsecode == "00" || $chargeResponsecode == "0") ) {
                 $curl = curl_init();
$headers = [];
curl_setopt_array($curl, array(
  CURLOPT_URL => "http://34.244.205.139/party/?action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  //CURLOPT_POSTFIELDS => "action=0&email_id=rdi@avante-cs.com&pass_key=Welcome123$",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response1 = curl_exec($curl);
 //echo $err = curl_error($curl).'<br><br>';
   $da=json_decode($response1,true);
 //echo 'tt';
   $token=$da["sessionID"];
   $ref_no=$da["ex_ref_no"];

  curl_close($curl);
$curls = curl_init();
$headers = [];
//$ref=22;
//get userid and get network

curl_setopt_array($curls, array(
  CURLOPT_URL => "http://34.244.205.139/party/?action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=$amount&vend_email=rdi@avante-cs.com&bill_id=$billid&item_id=$itemcode&phone_numb=$phone",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  //CURLOPT_POSTFIELDS => "action=1&ex_ref_no=$ref_no&sessionID=$token&trans_amt=50&vend_email=rdi@avante-cs.com&bill_id=1&item_id=M01&phone_numb=08136458772",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    
  ),
));

 $response12 = curl_exec($curls);
 //echo $httpcode = curl_getinfo($curls, CURLINFO_HTTP_CODE);
  $err = curl_error($curls).'<br><br>';
    $das=json_decode($response12,true);
 //echo 'tt';
   $session=$das["session_id"];
   $code=$das["ex_resp_code"];
  $ex_resp_desc=$das["ex_resp_desc"];
   
curl_close($curls);
          //Give Value and return to Success page
            //Save in database Paytransaction
            
$get_me2=mysqli_query($con2,"INSERT INTO `airtimerecord`( `submerchantId`, `userId`, `agentId`, `serialNo`, `transAmount`, `createdDate`, `transDate`)
													   VALUES('$submerchantId','$userid','$agentid','$serialNo','$totalairtime','$createdDate','$transDate')");

$rowsa=mysqli_fetch_array($get_me2);
 $points=stripslashes($rowsa[ap]);
 $rewards=stripslashes($rowsa[ra]);
//$submit_order3 = mysqli_query($connect,"UPDATE `paytransaction` SET `pay_status`='Paid',`date`=$date,`time`=$time WHERE `order_no`=$ref");
/* 
$airtimeqry = "INSERT INTO `airtimerecord`( `submerchantId`, `userId`, `agentId`, `serialNo`, `transAmount`, `createdDate`, `transDate`)
													   VALUES('$submerchantId','$userid','$agentid','$serialNo','$totalairtime','$createdDate','$transDate')";

									$airtimeqryresult =  mysqli_query($link2,$airtimeqry) or die(mysqli_error($link2));
*/

            echo 'Payment successful';
        } else {


            //Dont Give Value and return to Failure page
            echo 'error in payment, please contact support';
        }
    }

?>

</div>
												<!-- END PERSONAL INFO TAB -->
												<!-- END CHANGE AVATAR TAB -->
												</div>
						</div>
						
						<!-- END PROFILE CONTENT -->
					</div>
				</div>
				<!-- END PAGE CONTENT-->
			</div>
		</div>
		<!-- END CONTENT -->
		<!-- BEGIN QUICK SIDEBAR -->
		<!--Cooming Soon...-->
		<!-- END QUICK SIDEBAR -->
	</div>
<br><br><br><br><br><br><br><br><br><br>
  <!-- bottom line start //-->
<div class="bottom-line">
	<div class="container">
    	<div class="row">
        	<div class="span6">
            	<p>© 2017 All rights reserved.  MoLoyal by <a href="http://avante-cs.com" target="_blank">Avante Consulting Solutions</a></p>
            </div>
        	<div class="span6">
            	<p class="bottom-menu"><a href="consumer-benefits">Consumer Benefits</a> | <a href="business-benefits">Business Benefits</a> | <a href="faq">FAQ</a></p>
            </div>
        </div>
    </div>
</div>
<!-- bottom line end //-->

<!-- to the top start //-->
<div id="to-the-top"><i class="icon-angle-up"></i></div>
<!-- to the top end //-->



</body>

<!-- scripts start //-->
<script src="./js/jquery.js"></script>
<script src="./js/layerslider.kreaturamedia.jquery.js"></script>
<script src="./js/layerslider.transitions.js"></script>
<script src="./js/jquery-easing-1.3.js" type="text/javascript"></script>
<script src="./js/jquery-transit-modified.js" type="text/javascript"></script>
<script src="./js/jquery.jcarousel.min.js"></script>
<script type="text/javascript" src="./assets-newsletters/scripts/quick_newsletter.js"></script> 
<script src="./js/jquery.colorbox.js"></script>
<script src="./js/custom.js"></script>
<script>
jQuery(document).ready(function() {
});
</script>
<!-- scripts end //-->

</html>